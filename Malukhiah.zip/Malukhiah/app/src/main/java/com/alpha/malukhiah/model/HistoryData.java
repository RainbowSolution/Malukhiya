package com.alpha.malukhiah.model;

public class HistoryData {
    String ordername;

    public String getOrdername() {
        return ordername;
    }

    public HistoryData(String ordername) {
        this.ordername = ordername;
    }

    public void setOrdername(String ordername) {
        this.ordername = ordername;
    }


}